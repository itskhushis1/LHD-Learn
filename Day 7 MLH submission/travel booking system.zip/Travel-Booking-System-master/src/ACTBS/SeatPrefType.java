/**
 * Contributors: Tony Kolstee and Matthew Jett
 * Class: Design Patterns CSCD349-01 with Tom Capaul Spring 2018
 * Description: An enum that contains the list of types of seat preferences, like a window seat or an aisle.
 */

package ACTBS;


public enum SeatPrefType { window, aisle }
