/**
 * Contributors: Tony Kolstee and Matthew Jett
 * Class: Design Patterns CSCD349-01 with Tom Capaul Spring 2018
 * Description: An enum that contains the list of types of carriers, like Airlines or Cruise Liners.
 */

package ACTBS;


public enum CarrierType { airline, cruiseline }