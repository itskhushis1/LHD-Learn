/**
 * Contributors: Tony Kolstee and Matthew Jett
 * Class: Design Patterns CSCD349-01 with Tom Capaul Spring 2018
 * Description: An enum that contains the list of types of seat statuses, like booked or available.
 */

package ACTBS;


public enum SeatStatus { booked, available }
