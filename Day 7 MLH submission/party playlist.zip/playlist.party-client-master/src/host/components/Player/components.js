import styled from 'styled-components'

export const Container = styled.div`
  background: #151515;
  box-shadow: 0 -1px 12px rgba(0, 0, 0, .25);
  position: relative;
`
