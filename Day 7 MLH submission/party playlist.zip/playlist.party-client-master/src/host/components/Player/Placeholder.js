import styled from 'styled-components'
import { Container } from './components'

const Placeholder = styled(Container)`
  height: 120px;
`

export default Placeholder
