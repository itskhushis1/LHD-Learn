import styled from 'styled-components'

const Divider = styled.hr`
  opacity: .25;
  margin: 16px 0;
`

export default Divider
